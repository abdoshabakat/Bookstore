import React from 'react'

const Error = () => {
    return (
        <div>
            <h2>Oops. Error Page</h2>
        </div>
    )
}

export default Error
